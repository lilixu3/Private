package com.example.danmuapiapp

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnStart: com.google.android.material.button.MaterialButton
    private lateinit var btnStop: com.google.android.material.button.MaterialButton
    private lateinit var btnBattery: com.google.android.material.button.MaterialButton

    private val requestNotifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Start service anyway; on some Android versions the notification may be blocked without permission.
        startNodeServiceWithUiHint()
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            if (intent.action != NodeService.ACTION_NODE_STATUS) return
            val status = intent.getStringExtra(NodeService.EXTRA_STATUS) ?: return
            val msg = intent.getStringExtra(NodeService.EXTRA_MESSAGE) ?: ""
            when (status) {
                NodeService.STATUS_STARTING -> setUiStarting(msg)
                NodeService.STATUS_RUNNING -> setUiRunning(msg)
                NodeService.STATUS_STOPPED -> setUiStopped(msg)
                NodeService.STATUS_ERROR -> setUiError(msg)
                NodeService.STATUS_ALREADY_RUNNING -> setUiRunning(msg)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnBattery = findViewById(R.id.btnBattery)

        btnStart.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                val perm = Manifest.permission.POST_NOTIFICATIONS
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    requestNotifPerm.launch(perm)
                    return@setOnClickListener
                }
            }
            startNodeServiceWithUiHint()
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, NodeService::class.java))
            Toast.makeText(this, "已请求停止前台服务", Toast.LENGTH_SHORT).show()
            setUiStopped("已停止前台服务（注意：Node 进程是否退出取决于你的 JS 代码）")
        }

        btnBattery.setOnClickListener {
            openBatteryOptimization()
        }

        // 初始展示
        refreshUiFromServiceState()
    }

    override fun onStart() {
        super.onStart()
        registerStatusReceiver()
        refreshUiFromServiceState()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(statusReceiver)
        } catch (_: Throwable) {
        }
    }

    private fun refreshUiFromServiceState() {
        if (NodeService.isRunning()) {
            setUiRunning("Node 正在运行（前台服务）")
        } else {
            setUiStopped("未运行。点击“启动服务”后，Node 会在后台跑起来。")
        }
    }

    private fun startNodeServiceWithUiHint() {
        setUiStarting("启动中…请稍候（可在通知栏看到运行状态）")
        startNodeService()
        Toast.makeText(this, "已启动：后台服务运行中", Toast.LENGTH_SHORT).show()
        maybePromptBatteryOptimization()
    }

    private fun startNodeService() {
        val intent = Intent(this, NodeService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun setUiStarting(message: String) {
        tvStatus.text = message
        btnStart.isEnabled = false
        btnStop.isEnabled = true
    }

    private fun setUiRunning(message: String) {
        tvStatus.text = message
        btnStart.isEnabled = false
        btnStop.isEnabled = true
    }

    private fun setUiStopped(message: String) {
        tvStatus.text = message
        btnStart.isEnabled = true
        btnStop.isEnabled = false
    }

    private fun setUiError(message: String) {
        tvStatus.text = "启动失败：\n$message"
        btnStart.isEnabled = true
        btnStop.isEnabled = false
        Toast.makeText(this, "启动失败（详情见页面）", Toast.LENGTH_LONG).show()
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun isIgnoringBatteryOptimizations(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val pm = getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun maybePromptBatteryOptimization() {
        if (isIgnoringBatteryOptimizations()) return

        AlertDialog.Builder(this)
            .setTitle("后台常驻建议")
            .setMessage(
                "为了减少被系统省电策略限制，建议把本 App 的电池用量设置为“不受限制/无限制”，并允许忽略电池优化。\n\n" +
                        "点击“去设置”将打开系统页面（不同品牌入口可能略有差异）。"
            )
            .setNegativeButton("稍后") { d, _ -> d.dismiss() }
            .setPositiveButton("去设置") { d, _ ->
                d.dismiss()
                openBatteryOptimization()
            }
            .show()
    }

    private fun openBatteryOptimization() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !isIgnoringBatteryOptimizations()) {
                // 直接请求加入白名单
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
                return
            }
        } catch (_: Throwable) {
        }

        // 兜底：打开电池优化设置或 App 信息页（用户手动设置为“不受限制”）
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (_: Throwable) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }

    private fun registerStatusReceiver() {
        val filter = IntentFilter(NodeService.ACTION_NODE_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
    }
}
