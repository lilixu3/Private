package com.example.danmuapiapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val requestNotifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        // Start service anyway; on some Android versions the notification may be blocked without permission.
        startNodeService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tv = findViewById<TextView>(R.id.tvStatus)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)

        tv.text = "准备就绪。点击“启动”后，Node 会在后台跑起来。\n" +
                "入口: assets/nodejs-project/main.js（转发到 android-server.mjs）\n" +
                "默认端口: 9321（主服务）/ 5321（代理）"

        btnStart.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                val perm = Manifest.permission.POST_NOTIFICATIONS
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    requestNotifPerm.launch(perm)
                    return@setOnClickListener
                }
            }
            startNodeService()
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, NodeService::class.java))
            tv.text = "已停止 Service（注意：Node 进程是否退出取决于你的 JS 代码）"
        }
    }

    private fun startNodeService() {
        val intent = Intent(this, NodeService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
