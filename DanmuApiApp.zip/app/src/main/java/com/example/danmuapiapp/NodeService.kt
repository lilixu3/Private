package com.example.danmuapiapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class NodeService : Service() {

    companion object {
        private const val CHANNEL_ID = "danmuapi_node"
        private const val NOTIF_ID = 3001
        private val started = AtomicBoolean(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Node 正在运行（前台服务）"))

        if (started.compareAndSet(false, true)) {
            Thread {
                try {
                    val nodeProjectDir: File = AssetCopier.ensureNodeProjectExtracted(this)
                    val entryFile = File(nodeProjectDir, "main.js")
                    if (!entryFile.exists()) {
                        throw IllegalStateException("入口文件不存在: ${entryFile.absolutePath}（请确认 assets/nodejs-project/main.js 已打包）")
                    }
                    val entry = entryFile.absolutePath

                    // You can add more args here, e.g. "--trace-warnings"
                    @Suppress("UNUSED_VARIABLE")
                    val code = NodeBridge.startNodeWithArguments(arrayOf("node", entry))

                    // Node 退出时允许再次启动，并收尾前台服务
                    started.set(false)
                    // stopForeground(int) is API 24+. Keep minSdk 21 safe.
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                    } else {
                        @Suppress("DEPRECATION")
                        stopForeground(true)
                    }
                    stopSelf()
                } catch (t: Throwable) {
                    t.printStackTrace()
                    started.set(false)
                }
            }.start()
        }

        return START_STICKY
    }

    override fun onDestroy() {
        started.set(false)
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DanmuApiApp")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_node)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DanmuApi Node Service",
                NotificationManager.IMPORTANCE_LOW
            )
            mgr.createNotificationChannel(channel)
        }
    }
}
