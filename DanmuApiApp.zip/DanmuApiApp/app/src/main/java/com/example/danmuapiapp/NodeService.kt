package com.example.danmuapiapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class NodeService : Service() {

    companion object {
        private const val CHANNEL_ID = "danmuapi_node"
        private const val NOTIF_ID = 3001
        private val started = AtomicBoolean(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("Node 正在运行（前台服务）"))

        if (started.compareAndSet(false, true)) {
            Thread {
                try {
                    val nodeProjectDir: File = AssetCopier.ensureNodeProjectExtracted(this)
                    val entry = File(nodeProjectDir, "main.js").absolutePath

                    // You can add more args here, e.g. "--trace-warnings"
                    NodeBridge.startNodeWithArguments(arrayOf("node", entry))
                } catch (t: Throwable) {
                    t.printStackTrace()
                }
            }.start()
        }

        return START_STICKY
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DanmuApiApp")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_node)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DanmuApi Node Service",
                NotificationManager.IMPORTANCE_LOW
            )
            mgr.createNotificationChannel(channel)
        }
    }
}
