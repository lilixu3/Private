#!/system/bin/sh
PERSIST=/data/adb/danmu_api_server
PIDFILE="$PERSIST/danmu_api.pid"
LOGFILE="$PERSIST/logs/service.log"

if [ -f "$PIDFILE" ]; then
  PID="$(cat "$PIDFILE" 2>/dev/null)"
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    kill "$PID" 2>/dev/null
  fi
  rm -f "$PIDFILE" 2>/dev/null
fi

echo "[danmu_api] Module removed. Persistent data kept in $PERSIST (delete manually if you want)." >> "$LOGFILE" 2>/dev/null
