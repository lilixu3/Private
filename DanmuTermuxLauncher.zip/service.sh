#!/system/bin/sh
MODDIR=${0%/*}
PERSIST=/data/adb/danmu_api_server
LOGFILE="$PERSIST/logs/service.log"
PIDFILE="$PERSIST/danmu_api.pid"

mkdir -p "$PERSIST/logs" 2>/dev/null

# Wait for boot completion
if command -v resetprop >/dev/null 2>&1; then
  resetprop -w sys.boot_completed 0
else
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
  done
fi
sleep 10

# Find node binary
NODE_BIN=""
# 1) user override
if [ -n "$DANMU_API_NODE" ] && [ -x "$DANMU_API_NODE" ]; then
  NODE_BIN="$DANMU_API_NODE"
fi
# 2) common locations
for p in   /data/data/com.termux/files/usr/bin/node   /data/data/com.termux/files/usr/bin/nodejs   /data/adb/modules/nodejs/system/bin/node   /system/bin/node   /system/xbin/node   /vendor/bin/node
do
  [ -z "$NODE_BIN" ] && [ -x "$p" ] && NODE_BIN="$p"
done
# 3) PATH
if [ -z "$NODE_BIN" ]; then
  NODE_BIN="$(command -v node 2>/dev/null)"
  [ -x "$NODE_BIN" ] || NODE_BIN=""
fi

if [ -z "$NODE_BIN" ]; then
  echo "[danmu_api] Node.js not found. Please install Node.js (e.g. Termux: pkg install nodejs-lts) and reboot." >> "$LOGFILE"
  exit 0
fi

# Stop previous instance
if [ -f "$PIDFILE" ]; then
  OLD_PID="$(cat "$PIDFILE" 2>/dev/null)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    kill "$OLD_PID" 2>/dev/null
    sleep 1
  fi
  rm -f "$PIDFILE" 2>/dev/null
fi

cd "$MODDIR/app" || exit 0

export DANMU_API_HOME="$PERSIST"
export NODE_ENV=production

echo "[danmu_api] Starting with node: $NODE_BIN" >> "$LOGFILE"
nohup "$NODE_BIN" "$MODDIR/app/android-server.mjs" >> "$LOGFILE" 2>&1 &
echo $! > "$PIDFILE"
